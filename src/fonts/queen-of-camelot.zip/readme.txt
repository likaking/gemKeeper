Font: Queen of Camelot (Regular, Italic, and Outlines)
Version: 3.0 (updated 12/13/2016)
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


Long Live the Queen! Greetings subjects. This is an update of an older display all caps display font project containing more visually appealing glyphs with proportionate weights and kerning added. There is a smooth feel with the
rounded joins that has a consistent presence throughout it's entirety. This typeface has been a popular choice in publications, branding, and sports. Punctuation is included in the full version as is basic latin, some ligatures, 
and diacritics for Poland and Eastern Europe. Large update to many glyphs with modifications to kerning and accents. You can purchase this and all 3 versions for $15 or by acquiring a commercial license. Please note that this $15
is for PERSONAL use only and does not constitute a commercial license.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license.
If you've previously licensed the older version you're grandfathered into this version. Thank you! I also design custom fonts for businesses, logos, and many other things. If you'd like to 
leave me a donation you can use the same address via paypal. Your generosity will be most appreciated! Enjoy!


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: weight, sans, san serif, jolly, logo, sports, newspaper, headlines, book, publishing, title, curve, royal, undulating, curvy, font, typeface, branding, design, graphic, German, Polish, Europe, European, French, Latin

